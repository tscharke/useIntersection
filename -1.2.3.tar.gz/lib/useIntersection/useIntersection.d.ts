import { MutableRefObject, RefObject } from 'react';
type UseIntersectionProperties<T> = {
    ref: MutableRefObject<T> | RefObject<T>;
    options?: IntersectionObserverInit;
    triggerOnce?: boolean;
};
/**
 * A custom hook that uses the IntersectionObserver API to observe a DOM element.
 * @function useIntersection
 * @param {UseIntersectionProperties<T extends Element>} { ref, options, triggerOnce = false } - The properties for the hook.
 * @returns {Object} An object with a single property, intersecting, which is true if the element is intersecting.
 */
export declare const useIntersection: <T extends HTMLElement>({ ref, options, triggerOnce }: UseIntersectionProperties<T>) => {
    intersecting: boolean;
};
export {};
