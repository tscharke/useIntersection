/**
 * Function to observe an HTML element for intersection with the viewport.
 *
 * @param {HTMLElement} params.node - The HTML element to observe.
 * @param {(intersected: boolean) => void} params.setIntersecting - The function to call when the intersection state changes.
 * @param {IntersectionObserverInit} [params.options] - The options for the IntersectionObserver.
 * @param {boolean} [params.triggerOnce=false] - Whether to stop observing once the element has intersected.
 *
 * @returns {() => void} A function that can be called to stop observing the element.
 */
export declare const observeElement: ({ node, options, setIntersecting, triggerOnce }: {
    node: HTMLElement;
    setIntersecting: (intersected: boolean) => void;
    options?: IntersectionObserverInit;
    triggerOnce?: boolean;
}) => (() => void);
