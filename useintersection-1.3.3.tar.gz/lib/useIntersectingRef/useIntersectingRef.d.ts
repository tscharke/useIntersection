/**
 * A React hook that returns a ref callback and a state indicating whether the element is intersecting.
 * The ref callback should be passed to the element that needs to be observed for intersection.
 * The intersected state will be updated based on whether the element is intersecting or not.
 *
 * @template T The type of the HTML element that the ref will be attached to.
 * @returns An object containing the intersected state and the ref callback.
 */
export declare function useIntersectingRef<T extends HTMLElement>(): {
    intersected: boolean;
    ref: (node: T) => void;
};
